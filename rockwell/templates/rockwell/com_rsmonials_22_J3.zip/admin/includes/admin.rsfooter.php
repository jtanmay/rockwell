<?php
/**
 * @version 2.2
 * @package Joomla 3.x
 * @subpackage RS-Monials
 * @copyright (C) 2013-2022 RS Web Solutions (http://www.rswebsols.com)
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

echo '<div align="center">RSMonials version '.RSWEBSOLS_EXTENSION_VERSION.' | Developed By <a href="http://www.rswebsols.com" target="_blank">RS Web Solutions</a></div>';
echo '</div>';
?>